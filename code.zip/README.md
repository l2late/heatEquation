# heatEquation

This is the repo for the practical assignment of the TW3720TU - Advanced C++ course

